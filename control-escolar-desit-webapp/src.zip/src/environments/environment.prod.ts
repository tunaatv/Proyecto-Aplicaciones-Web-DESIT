export const environment = {
  production: true,
  url_api: 'https://proyecto-aplicaciones-web-desit-api.onrender.com'
};
