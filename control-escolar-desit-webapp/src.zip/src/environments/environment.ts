export const environment = {
  production: false,
  url_api: "http://127.0.0.1:8000"
};
